#!/usr/bin/env python3
"""
port_scanner.py - TCP Port Scanner
Author : Nooraleeman Al-shawesh
Program: Syntexhub
A multi-threaded TCP port scanner that checks for open ports on a host.
Scans a single port, a list, or a range; logs results (OPEN / CLOSED / TIMEOUT)
with full exception handling. Only scan hosts you are authorized to test.
"""

import socket
import threading
import argparse
import time
import logging
from datetime import datetime

# --------------------------- configuration ---------------------------------
DEFAULT_TIMEOUT = 1.0          # seconds per connection attempt
MAX_THREADS     = 200          # thread pool size
LOG_FILE        = "scan_results.log"

logging.basicConfig(
    filename=LOG_FILE,
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S",
)

# common ports -> service name (for a friendlier report)
COMMON_SERVICES = {
    21: "FTP", 22: "SSH", 23: "Telnet", 25: "SMTP", 53: "DNS",
    80: "HTTP", 110: "POP3", 143: "IMAP", 443: "HTTPS",
    445: "SMB", 3306: "MySQL", 3389: "RDP", 5432: "PostgreSQL",
    5900: "VNC", 8080: "HTTP-Alt",
}

print_lock   = threading.Lock()
results      = []              # (port, status, banner)


def resolve_host(host):
    """Resolve a hostname to an IPv4 address. Raises SystemExit on failure."""
    try:
        return socket.gethostbyname(host)
    except socket.gaierror:
        print(f"[!] Could not resolve host: {host}")
        logging.error(f"DNS resolution failed for {host}")
        raise SystemExit(1)


def scan_port(target_ip, port, timeout):
    """Try a TCP connect scan on one port; record OPEN/CLOSED/TIMEOUT."""
    status = "CLOSED"
    banner = ""
    try:
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sock.settimeout(timeout)
        result = sock.connect_ex((target_ip, port))
        if result == 0:
            status = "OPEN"
            try:  # best-effort banner grab
                sock.sendall(b"HEAD / HTTP/1.0\r\n\r\n")
                banner = sock.recv(64).decode(errors="ignore").strip()
            except Exception:
                banner = ""
        sock.close()
    except socket.timeout:
        status = "TIMEOUT"
    except OSError as exc:
        status = f"ERROR({exc.errno})"
    except Exception as exc:          # never crash the scanner on one port
        status = f"ERROR({type(exc).__name__})"
    finally:
        with print_lock:
            results.append((port, status, banner))
            service = COMMON_SERVICES.get(port, "")
            tag = f" ({service})" if service else ""
            print(f"[{status:>7}] Port {port:>5}/tcp{tag}"
                  + (f"  Banner: {banner[:50]}" if banner else ""))
            logging.info(f"Port {port}/tcp -> {status} {service}".strip())


def parse_ports(spec):
    """Accept '80', '22,80,443' or '1-1024' and return a sorted list of ports."""
    ports = set()
    for part in spec.split(","):
        part = part.strip()
        if "-" in part:
            start, end = part.split("-", 1)
            start, end = int(start), int(end)
            if not (0 < start <= end <= 65535):
                raise ValueError(f"Invalid range: {part}")
            ports.update(range(start, end + 1))
        else:
            p = int(part)
            if not (0 < p <= 65535):
                raise ValueError(f"Invalid port: {p}")
            ports.add(p)
    return sorted(ports)


def run_scan(host, ports):
    target_ip = resolve_host(host)
    print(f"\n[*] Scanning {host} ({target_ip}) - {len(ports)} port(s)")
    print(f"[*] Started at {datetime.now():%Y-%m-%d %H:%M:%S}\n")
    logging.info(f"Scan started: host={host} ip={target_ip} ports={len(ports)}")

    start = time.time()
    threads = []
    for port in ports:
        t = threading.Thread(target=scan_port, args=(target_ip, port, DEFAULT_TIMEOUT))
        t.start()
        threads.append(t)
        while threading.active_count() > MAX_THREADS:   # simple thread pool
            time.sleep(0.01)
    for t in threads:
        t.join()
    elapsed = time.time() - start

    open_ports = [p for p, s, _ in results if s == "OPEN"]
    print("\n" + "-" * 50)
    print(f"[*] Done in {elapsed:.2f}s | OPEN: {len(open_ports)} | "
          f"Total scanned: {len(results)}")
    logging.info(f"Scan finished in {elapsed:.2f}s, open={len(open_ports)}")
    return open_ports


def main():
    parser = argparse.ArgumentParser(
        description="Multi-threaded TCP port scanner (authorized use only).")
    parser.add_argument("host", help="Target hostname or IP address")
    parser.add_argument("-p", "--ports", default="1-1024",
                        help="Ports: '80', '22,80,443' or range '1-1024'")
    parser.add_argument("-t", "--timeout", type=float, default=1.0,
                        help="Connection timeout in seconds (default 1.0)")
    args = parser.parse_args()

    DEFAULT_TIMEOUT = args.timeout
    try:
        ports = parse_ports(args.ports)
    except ValueError as exc:
        parser.error(str(exc))
    run_scan(args.host, ports)


if __name__ == "__main__":
    main()
