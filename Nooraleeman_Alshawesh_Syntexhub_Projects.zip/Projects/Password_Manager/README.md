# Password Manager (Project 2)

Local, encrypted password manager using AES-256-GCM.

## Features
- Master password protected (PBKDF2-HMAC-SHA256, 200,000 iterations)
- Encrypted JSON storage on disk (`vault.enc`)
- Operations: add, retrieve, delete, search, list
- AES-GCM authenticated encryption (tamper-evident)

## Install & Run
    pip install -r requirements.txt
    python password_manager.py

## Security Notes
- The master password is never stored; only its derived key is used.
- AES-GCM detects any modification of the vault file.
