#!/usr/bin/env python3
"""
password_manager.py - Local Encrypted Password Manager
Author : Nooraleeman Al-shawesh
Program: Syntexhub
Stores credentials encrypted on disk (AES-GCM). The encryption key is derived
from a master password with PBKDF2-HMAC-SHA256 (200k iterations). Data is kept
as encrypted JSON (salt + nonce + ciphertext). Supports add / get / delete /
search / list operations.
"""

import os
import json
import base64
import getpass
from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.ciphers.aead import AESGCM

VAULT_FILE = "vault.enc"
PBKDF2_ITERATIONS = 200_000
KEY_LEN = 32   # bytes -> AES-256


# ------------------------------- crypto helpers -----------------------------
def derive_key(master_password: str, salt: bytes) -> bytes:
    """Derive a 256-bit AES key from the master password (PBKDF2-HMAC-SHA256)."""
    kdf = PBKDF2HMAC(
        algorithm=hashes.SHA256(),
        length=KEY_LEN,
        salt=salt,
        iterations=PBKDF2_ITERATIONS,
    )
    return kdf.derive(master_password.encode())


def encrypt_json(data: dict, master_password: str) -> bytes:
    """Serialize dict -> JSON -> AES-GCM encrypt. Output: salt|nonce|ct (b64)."""
    salt = os.urandom(16)
    key  = derive_key(master_password, salt)
    nonce = os.urandom(12)
    ciphertext = AESGCM(key).encrypt(nonce, json.dumps(data).encode(), None)
    blob = salt + nonce + ciphertext
    return base64.b64encode(blob)


def decrypt_json(blob_b64: bytes, master_password: str) -> dict:
    """Decrypt a vault blob back into a dict. Raises ValueError if password
    is wrong (AES-GCM authentication failure) or data is corrupted."""
    try:
        blob = base64.b64decode(blob_b64)
        salt, nonce, ciphertext = blob[:16], blob[16:28], blob[28:]
        key = derive_key(master_password, salt)
        plaintext = AESGCM(key).decrypt(nonce, ciphertext, None)
        return json.loads(plaintext.decode())
    except Exception:
        raise ValueError("Wrong master password or corrupted vault file.")


# ------------------------------- vault logic --------------------------------
def load_vault(master_password: str) -> dict:
    """Load vault; return empty structure if no vault exists yet."""
    if not os.path.exists(VAULT_FILE):
        return {"credentials": []}
    with open(VAULT_FILE, "rb") as f:
        return decrypt_json(f.read(), master_password)


def save_vault(vault: dict, master_password: str) -> None:
    with open(VAULT_FILE, "wb") as f:
        f.write(encrypt_json(vault, master_password))


def find_entry(vault, site, username):
    for e in vault["credentials"]:
        if e["site"].lower() == site.lower() and e["username"] == username:
            return e
    return None


# -------------------------------- operations --------------------------------
def add_credential(vault, master_password):
    site     = input("Site/Service: ").strip()
    username = input("Username: ").strip()
    if not site or not username:
        print("[!] Site and username are required."); return
    password = getpass.getpass("Password: ")
    if find_entry(vault, site, username):
        print("[!] An entry for this site + username already exists."); return
    vault["credentials"].append({"site": site, "username": username,
                                 "password": password})
    save_vault(vault, master_password)
    print(f"[+] Credential saved for {site}.")


def get_credential(vault):
    site = input("Site/Service: ").strip()
    matches = [e for e in vault["credentials"]
               if e["site"].lower() == site.lower()]
    if not matches:
        print("[-] No credential found."); return
    for e in matches:
        print(f"\nSite: {e['site']} | Username: {e['username']}")
        print(f"Password: {e['password']}")


def search_credentials(vault):
    term = input("Search term: ").strip().lower()
    matches = [e for e in vault["credentials"]
               if term in e["site"].lower() or term in e["username"].lower()]
    if not matches:
        print("[-] No matches."); return
    print(f"\n{len(matches)} match(es):")
    for e in matches:
        print(f"  - {e['site']} ({e['username']})")


def delete_credential(vault, master_password):
    site     = input("Site/Service: ").strip()
    username = input("Username: ").strip()
    entry = find_entry(vault, site, username)
    if not entry:
        print("[-] Entry not found."); return
    vault["credentials"].remove(entry)
    save_vault(vault, master_password)
    print("[+] Entry deleted.")


def list_credentials(vault):
    if not vault["credentials"]:
        print("Vault is empty."); return
    print(f"\nStored credentials ({len(vault['credentials'])}):")
    for i, e in enumerate(vault["credentials"], 1):
        print(f"  {i}. {e['site']} - {e['username']}")


# ----------------------------------- menu -----------------------------------
def main():
    print("=== Local Password Manager (AES-256-GCM) ===")
    master_password = getpass.getpass("Master password: ")
    try:
        vault = load_vault(master_password)
    except ValueError as exc:
        print(f"[!] {exc}"); return

    actions = {
        "1": ("Add credential",    lambda: add_credential(vault, master_password)),
        "2": ("Retrieve credential", get_credential),
        "3": ("Search credentials",  search_credentials),
        "4": ("Delete credential",   lambda: delete_credential(vault, master_password)),
        "5": ("List all credentials", list_credentials),
    }
    while True:
        print("\n1) Add  2) Retrieve  3) Search  4) Delete  5) List  0) Quit")
        choice = input("> ").strip()
        if choice == "0":
            print("Bye."); break
        if choice in actions:
            try:
                actions[choice][1]()
            except Exception as exc:
                print(f"[!] Operation failed: {exc}")
        else:
            print("Invalid option.")


if __name__ == "__main__":
    main()
